

<?php
// This page has been removed as per user request.
header('Location: dashboard.php');
exit;
